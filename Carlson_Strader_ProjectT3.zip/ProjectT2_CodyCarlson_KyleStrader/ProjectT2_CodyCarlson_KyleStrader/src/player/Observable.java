package player;

public interface Observable {
	
	public void sendMessage();

}
