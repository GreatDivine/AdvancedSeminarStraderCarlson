package player;

public interface Observer {
	
	public void process(int hp, int cash);
}
